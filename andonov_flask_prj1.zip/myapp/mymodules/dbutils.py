import os
import sqlite3

def get_connection():
    path = os.path.realpath('./myapp/data/mydb.db')
    connection = sqlite3.connect(path)
    return connection

def drop_table_users():
    connection = get_connection()
    cursor = connection.cursor() 
    sql = "DROP TABLE if exists mydb.users"
    cursor.execute(sql)
    connection.commit()
    connection.close()

def create_table_users():
    connection = get_connection()
    cursor = connection.cursor() 
    sql = "CREATE TABLE if not exists users (id int, username text, password text)"
    cursor.execute(sql)
    connection.commit()
    connection.close()


def insert_user(id, uname, upass):
    connection = get_connection()
    cursor = connection.cursor() 
    #user = (1, 'ivan_andonov78@yahoo.com', '6280')
    user = (id, uname, upass)
    sql = "INSERT INTO users VALUES(?, ?, ?)"
    cursor.execute(sql, user)
    """
    users = [
        (2, 'rolf', 'asdf'),
        (3, 'ann', 'xyz')
    ]
    cursor.executemany(insert_query, users)
    """
    connection.commit()
    connection.close()

def get_users():
    connection = get_connection()
    cursor = connection.cursor() 
    sql = "SELECT * from users"
    users = []
    for row in cursor.execute(sql):
        users.append(row)
    connection.commit()
    connection.close()
    return users