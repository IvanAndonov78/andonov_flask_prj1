import os
from flask import Flask
app = Flask(__name__)

if __name__ == '__main__':
    #app.run(host='127.0.0.1', debug=True)
    app.run()

# flask run --host=127.0.0.1 --port=80
# flas run => this will run the server at port:5000
