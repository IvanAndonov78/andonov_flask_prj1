import os
from myapp import mymodules
from myapp import app
from flask import render_template
from myapp.mymodules import dbutils
from myapp.mymodules import test
#from flask import send_from_directory

"""
@app.route('/favicon.ico')
def favicon():
    return send_from_directory(os.path.join(app.root_path, 'static/images'),
        'favicon.ico', mimetype='image/vnd.microsoft.icon')
"""
@app.route('/favicon.ico')
def ignore_favicon():
    return ''

# http://127.0.0.1:5000 
@app.route('/')
def index():
    return render_template('index.html')

# http://127.0.0.1:5000/test1
@app.route("/test1")
def test1():
    return "<p>Hello, World!</p>"

# http://127.0.0.1:5000/test2
@app.route("/test2")
def test2():
    return render_template('test2.html')

# http://127.0.0.1:5000/drop_table_users
@app.route("/drop_table_users")
def drop_table_users():
    dbutils.drop_table_users()
    return "<h1> The table users has been dropped! </h1>"

# http://127.0.0.1:5000/create_table_users
@app.route("/create_table_users")
def create_table_users():
    dbutils.create_table_users()
    return "<h1> A new table users has been created! </h1>"

# http://127.0.0.1:5000/create_users
@app.route("/create_users")
def create_users():
    dbutils.insert_user(1, 'ivan_andonov78@yahoo.com', '6280')
    dbutils.insert_user(2, 'visitor@andonovsd.com', '1111')
    return "<h1> New user entries have been created! </h1>"

# http://127.0.0.1:5000/display_users
@app.route("/display_users")
def display_users():
    users = dbutils.get_users()
    out = ''
    """
    for index, tuple in enumerate(users):
        out += tuple[1]
    """
    for x in users:
        out += '<p>'
        out += str(x[1])
        out += '</p>'    
    return out

# http://127.0.0.1:5000/test_dir_path
@app.route("/test_dir_path")
def test_dir_path():
    #dir_path = os.path.dirname(os.path.realpath(__file__))
    #return str(dir_path) #C:\andonovsd\andonovsd_flask\myapp
    dir_path = test.test_dir_path()
    return dir_path

