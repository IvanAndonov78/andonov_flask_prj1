import os
"""
def get_current_dir(os):
    dir_path = os.path.dirname(os.path.realpath(__file__))
    return dir_path
"""
def test_dir_path():
    #dir_path = os.path.dirname(os.path.realpath(__file__))
    # C:\andonovsd\andonovsd_flask\myapp\mymodules

    #dir_path = os.path.realpath(__file__) 
    # C:\andonovsd\andonovsd_flask\myapp\mymodules\test.py
    
    #dir_path = os.path.realpath('../data')
    # C:\andonovsd\data

    dir_path = os.path.realpath('./myapp/data/')
    #C:\andonovsd\andonovsd_flask\myapp\data
    return dir_path